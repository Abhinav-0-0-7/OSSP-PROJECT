# Linux Process Monitoring System

C/Linux project for process monitoring, process control, process creation, IPC, memory management, file I/O, threads and synchronization.

## Build

make

## Run

./process_monitor

## Clean

make clean
