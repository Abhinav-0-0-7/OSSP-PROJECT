#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include "process_control.h"

static void send_signal(int signal_no, const char *name)
{
    int pid;

    printf("Enter PID: ");
    if (scanf("%d", &pid) != 1 || pid <= 0) {
        printf("Invalid PID.\n");
        return;
    }

    if (kill((pid_t)pid, signal_no) == 0)
        printf("%s sent to PID %d.\n", name, pid);
    else
        printf("Unable to send %s: %s\n", name, strerror(errno));
}

void process_control_menu(void)
{
    int choice;

    while (1) {
        printf("\nPROCESS CONTROL\n");
        printf("1. SIGTERM - terminate\n");
        printf("2. SIGKILL - force terminate\n");
        printf("3. SIGSTOP - pause\n");
        printf("4. SIGCONT - continue\n");
        printf("0. Back\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1) {
            int c;
            while ((c = getchar()) != '\n' && c != EOF) {}
            printf("Invalid input.\n");
            continue;
        }

        switch (choice) {
            case 1: send_signal(SIGTERM, "SIGTERM"); break;
            case 2: send_signal(SIGKILL, "SIGKILL"); break;
            case 3: send_signal(SIGSTOP, "SIGSTOP"); break;
            case 4: send_signal(SIGCONT, "SIGCONT"); break;
            case 0: return;
            default: printf("Invalid choice.\n");
        }
    }
}
