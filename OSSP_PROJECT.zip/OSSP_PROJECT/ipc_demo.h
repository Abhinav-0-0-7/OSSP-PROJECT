#ifndef IPC_DEMO_H
#define IPC_DEMO_H

void ipc_menu(void);

#endif
