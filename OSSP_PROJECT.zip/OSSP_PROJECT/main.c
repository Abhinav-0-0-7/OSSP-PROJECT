#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include "process_monitor.h"
#include "process_control.h"
#include "ipc_demo.h"
#include "advanced_features.h"

static void menu(void)
{
    printf("\n=============================================\n");
    printf("       LINUX PROCESS MONITORING SYSTEM\n");
    printf("=============================================\n");
    printf("1. Process Monitoring & Resource Usage       [CO1]\n");
    printf("2. Process Control & Signal Management       [CO2]\n");
    printf("3. Process Creation & Management             [CO3]\n");
    printf("4. Inter-Process Communication               [CO4]\n");
    printf("5. Memory Management & Address Space         [CO4]\n");
    printf("6. Multithreading & Synchronization          [CO5]\n");
    printf("0. Exit\n");
    printf("---------------------------------------------\n");
    printf("Enter choice: ");
}

static void process_creation(void)
{
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return;
    }

    if (pid == 0) {
        printf("\nChild PID : %d\n", getpid());
        printf("Parent PID: %d\n", getppid());
        execl("/bin/echo", "echo", "Child process executed successfully.", (char *)NULL);
        perror("execl");
        _exit(1);
    }

    int status;
    printf("\nParent PID: %d\n", getpid());
    printf("Child  PID: %d\n", pid);

    if (waitpid(pid, &status, 0) == -1)
        perror("waitpid");
    else if (WIFEXITED(status))
        printf("Child exited with status %d.\n", WEXITSTATUS(status));
}

int main(void)
{
    int choice;

    while (1) {
        menu();

        if (scanf("%d", &choice) != 1) {
            int c;
            while ((c = getchar()) != '\n' && c != EOF) {}
            printf("Invalid input.\n");
            continue;
        }

        switch (choice) {
            case 1: show_processes(); break;
            case 2: process_control_menu(); break;
            case 3: process_creation(); break;
            case 4: ipc_menu(); break;
            case 5: co4_menu(); break;
            case 6: co5_menu(); break;
            case 0: return 0;
            default: printf("Invalid choice.\n");
        }
    }
}
