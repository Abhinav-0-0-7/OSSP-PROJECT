#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include "ipc_demo.h"

#define FIFO_PATH "/tmp/ossp_fifo"
#define SOCKET_PATH "/tmp/ossp_socket"

static void pipe_demo(void)
{
    int p[2];
    if (pipe(p) == -1) { perror("pipe"); return; }

    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return; }

    if (pid == 0) {
        char buf[128] = {0};
        close(p[1]);
        read(p[0], buf, sizeof(buf) - 1);
        printf("\nChild received: %s\n", buf);
        close(p[0]);
        _exit(0);
    }

    close(p[0]);
    write(p[1], "Message through anonymous pipe.", 31);
    close(p[1]);
    waitpid(pid, NULL, 0);
}

static void fifo_demo(void)
{
    unlink(FIFO_PATH);
    if (mkfifo(FIFO_PATH, 0666) == -1 && errno != EEXIST) {
        perror("mkfifo");
        return;
    }

    pid_t pid = fork();
    if (pid < 0) { perror("fork"); unlink(FIFO_PATH); return; }

    if (pid == 0) {
        int fd = open(FIFO_PATH, O_RDONLY);
        char buf[128] = {0};
        if (fd != -1) {
            read(fd, buf, sizeof(buf) - 1);
            printf("\nFIFO received: %s\n", buf);
            close(fd);
        }
        _exit(0);
    }

    sleep(1);
    int fd = open(FIFO_PATH, O_WRONLY);
    if (fd != -1) {
        write(fd, "Message through named FIFO.", 27);
        close(fd);
    }
    waitpid(pid, NULL, 0);
    unlink(FIFO_PATH);
}

static volatile sig_atomic_t got_signal;

static void handler(int sig)
{
    if (sig == SIGUSR1) got_signal = 1;
}

static void signal_demo(void)
{
    struct sigaction sa = {0};
    sa.sa_handler = handler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, NULL);

    pid_t pid = fork();
    if (pid == 0) {
        sleep(1);
        kill(getppid(), SIGUSR1);
        _exit(0);
    }

    printf("\nWaiting for SIGUSR1...\n");
    while (!got_signal) pause();
    printf("SIGUSR1 received from child.\n");
    waitpid(pid, NULL, 0);
}

static void socket_demo(void)
{
    int server = socket(AF_UNIX, SOCK_STREAM, 0);
    if (server == -1) { perror("socket"); return; }

    struct sockaddr_un addr = {0};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, SOCKET_PATH, sizeof(addr.sun_path) - 1);
    unlink(SOCKET_PATH);

    if (bind(server, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
        perror("bind"); close(server); return;
    }
    listen(server, 1);

    pid_t pid = fork();
    if (pid == 0) {
        sleep(1);
        int client = socket(AF_UNIX, SOCK_STREAM, 0);
        connect(client, (struct sockaddr *)&addr, sizeof(addr));
        write(client, "Message through UNIX socket.", 29);
        close(client);
        _exit(0);
    }

    int client = accept(server, NULL, NULL);
    char buf[128] = {0};
    read(client, buf, sizeof(buf) - 1);
    printf("\nSocket received: %s\n", buf);
    close(client);
    waitpid(pid, NULL, 0);
    close(server);
    unlink(SOCKET_PATH);
}

static void shared_memory_demo(void)
{
    int id = shmget(IPC_PRIVATE, 256, IPC_CREAT | 0600);
    if (id == -1) { perror("shmget"); return; }

    char *mem = shmat(id, NULL, 0);
    if (mem == (char *)-1) { perror("shmat"); return; }

    pid_t pid = fork();
    if (pid == 0) {
        sleep(1);
        printf("\nShared memory: %s\n", mem);
        shmdt(mem);
        _exit(0);
    }

    strcpy(mem, "Process status stored in shared memory.");
    waitpid(pid, NULL, 0);
    shmdt(mem);
    shmctl(id, IPC_RMID, NULL);
}

void ipc_menu(void)
{
    int choice;

    while (1) {
        printf("\nINTER-PROCESS COMMUNICATION\n");
        printf("1. Anonymous pipe\n");
        printf("2. Named pipe (FIFO)\n");
        printf("3. Signal communication\n");
        printf("4. UNIX domain socket\n");
        printf("5. Shared memory\n");
        printf("0. Back\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1) {
            int c;
            while ((c = getchar()) != '\n' && c != EOF) {}
            continue;
        }

        switch (choice) {
            case 1: pipe_demo(); break;
            case 2: fifo_demo(); break;
            case 3: signal_demo(); break;
            case 4: socket_demo(); break;
            case 5: shared_memory_demo(); break;
            case 0: return;
            default: printf("Invalid choice.\n");
        }
    }
}
