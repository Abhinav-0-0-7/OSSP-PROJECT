#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <pthread.h>
#include <semaphore.h>

/* CO4 */

static int global_value = 10;

static void memory_layout(void)
{
    static int static_value = 20;
    int stack_value = 30;
    int *heap_value = malloc(sizeof(int));

    if (!heap_value) { perror("malloc"); return; }
    *heap_value = 40;

    printf("\nCO4 - Memory Layout\n");
    printf("Code   : %p\n", (void *)memory_layout);
    printf("Global : %p\n", (void *)&global_value);
    printf("Static : %p\n", (void *)&static_value);
    printf("Heap   : %p\n", (void *)heap_value);
    printf("Stack  : %p\n", (void *)&stack_value);

    free(heap_value);
}

static void dynamic_memory(void)
{
    int *a = malloc(5 * sizeof(int));
    int *b = calloc(5, sizeof(int));
    if (!a || !b) { perror("allocation"); free(a); free(b); return; }

    for (int i = 0; i < 5; ++i) a[i] = i + 1;

    int *tmp = realloc(a, 10 * sizeof(int));
    if (!tmp) { perror("realloc"); free(a); free(b); return; }
    a = tmp;

    printf("\nCO4 - Dynamic Memory\n");
    printf("malloc()  : allocated memory\n");
    printf("calloc()  : allocated zero-initialized memory\n");
    printf("realloc() : resized allocation\n");
    printf("free()    : released memory\n");

    free(a);
    free(b);
}

static void file_copy(void)
{
    const char *src = "co4_source.txt";
    const char *dst = "co4_copy.txt";

    int f = open(src, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (f == -1) { perror("open"); return; }

    const char *text = "Low-level Linux file I/O.\n";
    write(f, text, strlen(text));
    close(f);

    int in = open(src, O_RDONLY);
    int out = open(dst, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (in == -1 || out == -1) {
        perror("open");
        if (in != -1) close(in);
        if (out != -1) close(out);
        return;
    }

    char buf[256];
    ssize_t n;
    while ((n = read(in, buf, sizeof(buf))) > 0)
        write(out, buf, (size_t)n);

    close(in);
    close(out);
    printf("\nCO4 - File copy completed using open/read/write/close.\n");
}

static void mmap_demo(void)
{
    const char *text = "Data written through mmap().\n";
    size_t len = strlen(text) + 1;
    int fd = open("co4_mmap.txt", O_RDWR | O_CREAT | O_TRUNC, 0644);

    if (fd == -1) { perror("open"); return; }
    if (ftruncate(fd, (off_t)len) == -1) { perror("ftruncate"); close(fd); return; }

    char *map = mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (map == MAP_FAILED) { perror("mmap"); close(fd); return; }

    memcpy(map, text, len);
    msync(map, len, MS_SYNC);
    printf("\nCO4 - Memory-mapped file:\n%s", map);

    munmap(map, len);
    close(fd);
}

static void copy_on_write(void)
{
    char *data = malloc(128);
    if (!data) { perror("malloc"); return; }

    strcpy(data, "Parent data before fork.");
    pid_t pid = fork();

    if (pid == -1) { perror("fork"); free(data); return; }

    if (pid == 0) {
        data[0] = 'C';
        printf("\nCO4 - Child copy: %s\n", data);
        free(data);
        _exit(0);
    }

    waitpid(pid, NULL, 0);
    printf("CO4 - Parent copy: %s\n", data);
    free(data);
}

void co4_menu(void)
{
    int c;
    while (1) {
        printf("\nCO4\n");
        printf("1. Memory layout\n");
        printf("2. Dynamic memory allocation\n");
        printf("3. Low-level file copy\n");
        printf("4. Memory-mapped I/O\n");
        printf("5. Copy-on-Write\n");
        printf("0. Back\n");
        printf("Enter choice: ");

        if (scanf("%d", &c) != 1) {
            int x; while ((x = getchar()) != '\n' && x != EOF) {}
            continue;
        }

        switch (c) {
            case 1: memory_layout(); break;
            case 2: dynamic_memory(); break;
            case 3: file_copy(); break;
            case 4: mmap_demo(); break;
            case 5: copy_on_write(); break;
            case 0: return;
            default: printf("Invalid choice.\n");
        }
    }
}

/* CO5 */

typedef struct {
    long *value;
    long count;
    pthread_mutex_t *lock;
} CounterArgs;

static void *counter_thread(void *arg)
{
    CounterArgs *a = arg;
    for (long i = 0; i < a->count; ++i) {
        pthread_mutex_lock(a->lock);
        ++(*a->value);
        pthread_mutex_unlock(a->lock);
    }
    return NULL;
}

static void thread_demo(void)
{
    pthread_t a, b;
    pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
    long value = 0;
    CounterArgs args = {&value, 100000, &lock};

    pthread_create(&a, NULL, counter_thread, &args);
    pthread_create(&b, NULL, counter_thread, &args);
    pthread_join(a, NULL);
    pthread_join(b, NULL);

    printf("\nCO5 - Threads and Mutex\n");
    printf("Final synchronized counter: %ld\n", value);

    pthread_mutex_destroy(&lock);
}

typedef struct {
    int buffer[4];
    int in;
    int out;
    sem_t empty;
    sem_t full;
    pthread_mutex_t lock;
} Buffer;

static void *produce(void *arg)
{
    Buffer *b = arg;
    for (int i = 1; i <= 10; ++i) {
        sem_wait(&b->empty);
        pthread_mutex_lock(&b->lock);
        b->buffer[b->in] = i;
        b->in = (b->in + 1) % 4;
        pthread_mutex_unlock(&b->lock);
        sem_post(&b->full);
    }
    return NULL;
}

static void *consume(void *arg)
{
    Buffer *b = arg;
    for (int i = 0; i < 10; ++i) {
        sem_wait(&b->full);
        pthread_mutex_lock(&b->lock);
        int value = b->buffer[b->out];
        b->out = (b->out + 1) % 4;
        pthread_mutex_unlock(&b->lock);
        sem_post(&b->empty);
        printf("Consumed: %d\n", value);
    }
    return NULL;
}

static void producer_consumer(void)
{
    Buffer b = {0};
    sem_init(&b.empty, 0, 4);
    sem_init(&b.full, 0, 0);
    pthread_mutex_init(&b.lock, NULL);

    pthread_t p, c;
    pthread_create(&p, NULL, produce, &b);
    pthread_create(&c, NULL, consume, &b);
    pthread_join(p, NULL);
    pthread_join(c, NULL);

    printf("CO5 - Producer-consumer completed.\n");

    pthread_mutex_destroy(&b.lock);
    sem_destroy(&b.empty);
    sem_destroy(&b.full);
}

static void deadlock_prevention(void)
{
    pthread_mutex_t first = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_t second = PTHREAD_MUTEX_INITIALIZER;

    printf("\nCO5 - Deadlock Prevention\n");
    printf("Both resources are always acquired in the same order.\n");

    pthread_mutex_lock(&first);
    pthread_mutex_lock(&second);
    printf("Resources acquired without circular wait.\n");
    pthread_mutex_unlock(&second);
    pthread_mutex_unlock(&first);

    pthread_mutex_destroy(&first);
    pthread_mutex_destroy(&second);
}

void co5_menu(void)
{
    int c;
    while (1) {
        printf("\nCO5\n");
        printf("1. POSIX threads and mutex\n");
        printf("2. Producer-consumer with semaphores\n");
        printf("3. Deadlock prevention\n");
        printf("0. Back\n");
        printf("Enter choice: ");

        if (scanf("%d", &c) != 1) {
            int x; while ((x = getchar()) != '\n' && x != EOF) {}
            continue;
        }

        switch (c) {
            case 1: thread_demo(); break;
            case 2: producer_consumer(); break;
            case 3: deadlock_prevention(); break;
            case 0: return;
            default: printf("Invalid choice.\n");
        }
    }
}
