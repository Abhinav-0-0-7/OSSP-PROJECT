#ifndef ADVANCED_FEATURES_H
#define ADVANCED_FEATURES_H

void co4_menu(void);
void co5_menu(void);

#endif
