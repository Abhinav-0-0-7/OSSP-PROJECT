#ifndef PROCESS_CONTROL_H
#define PROCESS_CONTROL_H

void process_control_menu(void);

#endif
