#ifndef PROCESS_MONITOR_H
#define PROCESS_MONITOR_H

void show_processes(void);
void create_test_process(void);

#endif
