#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/types.h>
#include "process_monitor.h"

static int numeric_name(const char *s)
{
    if (!s || !*s) return 0;
    for (int i = 0; s[i]; ++i)
        if (!isdigit((unsigned char)s[i])) return 0;
    return 1;
}

static int process_info(const char *pid, char *state, int *ppid,
                        unsigned long long *cpu, long *rss,
                        char *command, size_t size)
{
    char path[256], line[4096];
    FILE *fp;

    snprintf(path, sizeof(path), "/proc/%s/stat", pid);
    fp = fopen(path, "r");
    if (!fp) return -1;

    if (!fgets(line, sizeof(line), fp)) {
        fclose(fp);
        return -1;
    }
    fclose(fp);

    char *end = strrchr(line, ')');
    if (!end || end[1] != ' ') return -1;

    *state = end[2];

    char rest[4096];
    strncpy(rest, end + 4, sizeof(rest) - 1);
    rest[sizeof(rest) - 1] = '\0';

    unsigned long long v[32] = {0};
    int n = 0;
    char *save = NULL;
    char *tok = strtok_r(rest, " ", &save);

    while (tok && n < 32) {
        v[n++] = strtoull(tok, NULL, 10);
        tok = strtok_r(NULL, " ", &save);
    }

    if (n < 21) return -1;

    *ppid = (int)v[0];
    *cpu = v[10] + v[11];
    *rss = (long)v[20];

    snprintf(path, sizeof(path), "/proc/%s/cmdline", pid);
    fp = fopen(path, "r");
    if (fp) {
        size_t got = fread(command, 1, size - 1, fp);
        fclose(fp);
        for (size_t i = 0; i < got; ++i)
            if (command[i] == '\0') command[i] = ' ';
        command[got] = '\0';
    } else {
        command[0] = '\0';
    }

    if (!command[0])
        snprintf(command, size, "[kernel/process]");

    return 0;
}

void show_processes(void)
{
    DIR *dir = opendir("/proc");
    if (!dir) {
        perror("opendir");
        return;
    }

    printf("\n%-8s %-8s %-6s %-12s %-12s %s\n",
           "PID", "PPID", "STATE", "CPU TICKS", "MEM(KB)", "COMMAND");
    printf("--------------------------------------------------------------------------\n");

    struct dirent *e;
    int shown = 0;

    while ((e = readdir(dir)) && shown < 80) {
        if (!numeric_name(e->d_name)) continue;

        char state, command[256];
        int ppid;
        unsigned long long cpu;
        long rss;

        if (process_info(e->d_name, &state, &ppid, &cpu, &rss,
                         command, sizeof(command)) != 0)
            continue;

        long mem_kb = rss * sysconf(_SC_PAGESIZE) / 1024;

        printf("%-8s %-8d %-6c %-12llu %-12ld %.70s\n",
               e->d_name, ppid, state, cpu, mem_kb, command);
        ++shown;
    }

    closedir(dir);
    printf("\nProcesses displayed: %d\n", shown);
}

static void worker(void)
{
    for (int i = 1; i <= 10; ++i) {
        printf("Test process running: %d/10\n", i);
        fflush(stdout);
        sleep(1);
    }
}

void create_test_process(void)
{
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return;
    }

    if (pid == 0) {
        worker();
        _exit(0);
    }

    printf("\nTest process created. PID: %d\n", pid);
    printf("Use option 1 to view it and option 2 to control it.\n");
}
